# Digital Prime Agency — projet Remotion

Publicité motion design verticale de 40 secondes, 1080 × 1920, 30 FPS.

## Prérequis
Ordinateur Windows/macOS/Linux, Node.js 20 LTS conseillé, connexion Internet.
Un téléphone Android seul n'est pas recommandé pour installer et rendre ce projet.

## Installation
1. Décompressez le ZIP.
2. Ouvrez un terminal dans le dossier du projet.
3. Lancez `npm install`.

## Prévisualisation
Lancez `npm run dev`, puis ouvrez Remotion Studio dans le navigateur.

## Export MP4
Lancez `npm run render`.
Le fichier sera créé dans `out/digital-prime-ad.mp4`.

## Personnalisation
- Logo : `public/digital-prime-logo.png`
- Scènes : `src/DigitalPrimeAd.tsx`
- Illustrations : `src/components/Art.tsx`

## Palette
Bleu `#0878F9`, noir `#071225`, blanc `#F7FAFF`.

## Note importante
Le ZIP contient les sources Remotion et le logo. Ce n'est pas un MP4 déjà rendu.
La version actuelle comporte des illustrations vectorielles animées et une direction visuelle de départ. La voix off et la musique doivent encore être enregistrées/ajoutées pour une version finale de diffusion.
