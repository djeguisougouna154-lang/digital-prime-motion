import React from "react";
const navy="#071225", blue="#0878F9", pale="#EAF2FF";
export const Shop:React.FC=()=> <svg width="620" height="560" viewBox="0 0 620 560">
<ellipse cx="310" cy="510" rx="270" ry="27" fill={navy} opacity=".12"/>
<path d="M86 188L128 80H493L535 188" fill={blue}/><path d="M103 187H517V470H103Z" fill="white" stroke={navy} strokeWidth="12"/>
<path d="M78 183H542V235H78Z" fill={navy}/><path d="M151 265H469V470H151Z" fill={pale} stroke={navy} strokeWidth="9"/>
<path d="M276 265V470M151 354H469" stroke={navy} strokeWidth="8"/>
<rect x="180" y="294" width="65" height="42" rx="8" fill={blue}/><rect x="300" y="294" width="135" height="42" rx="8" fill="#B9D7FF"/>
<rect x="180" y="380" width="65" height="62" rx="8" fill="#B9D7FF"/><rect x="300" y="380" width="135" height="62" rx="8" fill={blue}/>
<path d="M86 188Q132 258 178 188Q224 258 270 188Q316 258 362 188Q408 258 454 188Q500 258 542 188" fill="white" stroke={navy} strokeWidth="8"/>
<text x="310" y="145" textAnchor="middle" fontSize="31" fontWeight="900" fill="white">BOUTIQUE</text></svg>;
export const Person:React.FC<{happy?:boolean}> = ({happy=false})=><svg width="280" height="410" viewBox="0 0 280 410">
<ellipse cx="140" cy="390" rx="100" ry="14" fill={navy} opacity=".12"/><path d="M55 390Q58 260 85 235H195Q222 265 225 390Z" fill={happy?blue:navy}/>
<rect x="123" y="194" width="34" height="55" rx="14" fill="#8D543B"/><ellipse cx="140" cy="140" rx="70" ry="84" fill="#A96C4D"/>
<path d="M70 140Q65 48 145 45Q225 50 210 140Q190 88 145 90Q105 90 70 140Z" fill="#171923"/>
<circle cx="115" cy="145" r="5" fill={navy}/><circle cx="166" cy="145" r="5" fill={navy}/>
{happy?<path d="M115 178Q140 200 166 178" stroke={navy} strokeWidth="7" fill="none" strokeLinecap="round"/>:<path d="M116 184Q140 174 165 184" stroke={navy} strokeWidth="6" fill="none" strokeLinecap="round"/>}
<path d="M65 275L25 350M215 275L255 350" stroke="#A96C4D" strokeWidth="25" strokeLinecap="round"/></svg>;
export const Phone:React.FC=()=> <svg width="240" height="420" viewBox="0 0 240 420"><rect x="15" y="5" width="210" height="410" rx="32" fill={navy}/><rect x="27" y="22" width="186" height="376" rx="23" fill="#F7FAFF"/><circle cx="120" cy="83" r="29" fill={blue}/><path d="M105 83L117 95L138 70" stroke="white" strokeWidth="8" fill="none" strokeLinecap="round"/><rect x="52" y="137" width="136" height="16" rx="8" fill={navy}/><rect x="52" y="168" width="100" height="10" rx="5" fill="#9AA9BF"/><rect x="52" y="205" width="136" height="75" rx="12" fill="#DCEBFF"/><rect x="65" y="218" width="50" height="50" rx="8" fill={blue}/><path d="M130 228H175M130 245H170M130 262H160" stroke={navy} strokeWidth="6" strokeLinecap="round"/><rect x="52" y="300" width="136" height="43" rx="11" fill={blue}/><text x="120" y="328" textAnchor="middle" fontSize="15" fontWeight="bold" fill="white">CONTACT</text></svg>;
